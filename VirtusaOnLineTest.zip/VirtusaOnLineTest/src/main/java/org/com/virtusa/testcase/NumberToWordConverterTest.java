package org.com.virtusa.testcase;

import org.com.virtusa.NumberToWord;
/*import org.junit.Assert;

import org.mockito.Mock;*/

 

import org.testng.annotations.Test;
public class NumberToWordConverterTest {
	//  @Test

	  public void checkForNonValidInteger()

	      {

	 

	  //  Assert.assertEquals(NumberToWord.ConvertNumberToWords("6789543"), "six Million, seven hundred eighty nine Thousand, five hundred forty three");

	   

	  }

	 
}
